package xdm

import junit.framework.TestCase
import xdm.core.downloaders.web.streaming.manifest.hls.HlsParser
import java.nio.file.Files
import java.nio.file.Paths

class AppTest : TestCase() {
    fun testApp() {
        println("Hello")
        HlsParser.parseMediaSegments(
            Files.lines(Paths.get(javaClass.getResource("/file1.m3u8")?.toURI() ?: null)).iterator(),
            "http://playlist"
        ).onSuccess {
            println(it)
        }
    }
}