package xdm.app.constants;

public enum FilterItemType {
  ALL,
  UNFINISHED,
  FINISHED,
  CATEGORY_UNFINISHED,
  CATEGORY_FINISHED,
  ALL_QUEUE,
  QUEUE_ITEM;
}
