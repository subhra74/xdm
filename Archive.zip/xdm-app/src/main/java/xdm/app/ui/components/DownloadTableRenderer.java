package xdm.app.ui.components;

import xdm.app.utils.AppUtils;
import xdman.DownloadEntry;
import xdman.XDMConstants;
import xdman.ui.res.StringResource;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableCellRenderer;
import java.awt.*;

import static xdman.util.FormatUtilities.formatSize;

public class DownloadTableRenderer implements TableCellRenderer {
  private JLabel lbl, lbl2;

  public DownloadTableRenderer() {
    lbl = new JLabel("Some text");
    lbl.setIcon(AppUtils.createSVGIcon("file-zip-fill.svg", 20, Color.GRAY));
    lbl.setIconTextGap(10);
    lbl.setOpaque(true);
    lbl.setBorder(new EmptyBorder(7, 10, 6, 5));

    lbl2 = new JLabel("Some text");
    lbl2.setOpaque(true);
    lbl2.setBorder(new EmptyBorder(6, 5, 6, 5));
  }

  public int getCellHeight() {
    return Math.min(lbl.getPreferredSize().height, lbl2.getPreferredSize().height);
  }

  @Override
  public Component getTableCellRendererComponent(
      JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    var ent = (DownloadEntry) value;
    var label = column == 0 ? lbl : lbl2;
    String text;
    switch (column) {
      case 0:
        text = ent.getFile();
        break;
      case 1:
        text = formatSize(ent.getSize());
        break;
      case 2:
        text = ent.getDateStr();
        break;
      case 3:
        if (ent.getState() == XDMConstants.FINISHED) {
          text = StringResource.get("STAT_FINISHED");
        } else if (ent.getState() == XDMConstants.PAUSED || ent.getState() == XDMConstants.FAILED) {
          text = StringResource.get("STAT_PAUSED");
        } else if (ent.getState() == XDMConstants.ASSEMBLING) {
          text = StringResource.get("STAT_ASSEMBLING");
        } else {
          text = StringResource.get("STAT_DOWNLOADING");
        }
        break;
      default:
        text = "";
    }
    label.setText(text);
    label.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
    return label;
  }
}
