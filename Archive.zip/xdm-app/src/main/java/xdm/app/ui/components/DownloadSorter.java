package xdm.app.ui.components;

import xdm.app.AppContext;
import xdm.app.data.DbRecord;
// import xdm.app.models.DownloadEntry;

import java.util.Comparator;

public class DownloadSorter implements Comparator<DbRecord> {

  @Override
  public int compare(DbRecord o1, DbRecord o2) {
    var sortKey = AppContext.INSTANCE.getConfig().getSortKey();
    var ascending = AppContext.INSTANCE.getConfig().isSortAscending();
    int res = 0;
    switch (sortKey) {
      case NAME: // sort by name
        res = o1.getFileName().compareTo(o2.getFileName());
        break;
      case SIZE: // sort by size
        res = Long.compare(o1.getSize(), o2.getSize());
        break;
      case DATE: // sort by date
        res = Long.compare(o1.getDate(), o2.getDate());
        break;
      case TYPE: // sort by type
        res = o1.getStatus().compareTo(o2.getStatus());
        break;
      default:
        break;
    }
    return ascending ? -res : res;
  }
}
