package xdm.app.ui.components;

import com.formdev.flatlaf.FlatClientProperties;
import xdm.app.utils.AppUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LeftPanelCellRenderer implements ListCellRenderer<String> {

  @Override
  public Component getListCellRendererComponent(
      JList<? extends String> list,
      String value,
      int index,
      boolean isSelected,
      boolean cellHasFocus) {
    var label = new JLabel();
    label.putClientProperty(FlatClientProperties.STYLE, "arc: 8");
    label.setText(value);
    label.setIcon(AppUtils.createSVGIcon("arrow-up-down-fill.svg", 20, Color.GRAY));
    label.setIconTextGap(10);
    label.setBorder(new EmptyBorder(5, 10, 5, 30));
    label.setOpaque(true);
    label.setBackground(
        isSelected ? list.getSelectionBackground() : UIManager.getColor("Panel.background"));
    label.setForeground(isSelected ? list.getSelectionForeground() : list.getForeground());
    return label;
  }
}
