package xdm.app.ui.components;

import java.util.*;

import javax.swing.table.*;

import xdman.*;
import xdman.ui.components.DownloadSorter;
import xdman.util.Logger;

public class DownloadTableModel extends AbstractTableModel implements ListChangeListener {
  private List<String> idList;
  private Map<String, Integer> idIndexMap;
  private String[] headers = new String[] {"Name", "Size", "Date", "Status", "ETA", "Speed"};
  private boolean inProgress;

  public DownloadTableModel() {
    idList = new ArrayList<>();
    idIndexMap = new HashMap<>();
  }

  public void setInProgressMode(boolean inProgress) {
    this.inProgress = inProgress;
    fireTableStructureChanged();
  }

  @Override
  public int getColumnCount() {
    return inProgress ? headers.length : 4;
  }

  @Override
  public int getRowCount() {
    return idList.size();
  }

  @Override
  public String getColumnName(int column) {
    return headers[column];
  }

  @Override
  public Class<?> getColumnClass(int c) {
    return DownloadEntry.class;
  }

  @Override
  public Object getValueAt(int row, int col) {
    return getItemAt(row);
  }

  @Override
  public void listChanged() {
    Logger.log("List changed");
    idList =
        XDMApp.getInstance()
            .getDownloadList(
                Config.getInstance().getCategoryFilter(),
                Config.getInstance().getStateFilter(),
                Config.getInstance().getSearchText(),
                Config.getInstance().getQueueIdFilter());
    refreshIdMap();
    fireTableDataChanged();
  }

  @Override
  public void listItemUpdated(String id) {
    Logger.log("List updated");
    Integer index = idIndexMap.get(id);
    if (index != null) {
      fireTableRowsUpdated(index, index);
    }
  }

  private void refreshIdMap() {
    idIndexMap = new HashMap<>();
    for (int i = 0; i < idList.size(); i++) {
      idIndexMap.put(idList.get(i), i);
    }
  }

  public String getIdAt(int index) {
    return idList.get(index);
  }

  public int getIndexOfId(String id) {
    for (int i = 0; i < idList.size(); i++) {
      if (idList.get(i).equals(id)) return i;
    }
    return -1;
  }

  public DownloadEntry getItemAt(int index) {
    String id = idList.get(index);
    if (id == null) return null;
    return XDMApp.getInstance().getEntry(id);
  }
}
