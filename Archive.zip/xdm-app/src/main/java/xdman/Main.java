package xdman;

import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import xdman.util.Logger;

import javax.swing.*;
import java.awt.*;

public class Main {
  static {
    System.setProperty("http.KeepAlive.remainingData", "0");
    System.setProperty("http.KeepAlive.queuedConnections", "0");
    System.setProperty("sun.net.http.errorstream.enableBuffering", "false");
    System.setProperty("awt.useSystemAAFontSettings", "lcd");
    System.setProperty("swing.aatext", "true");
    System.setProperty("sun.java2d.d3d", "false");
    System.setProperty("sun.java2d.opengl", "false");
    System.setProperty("sun.java2d.xrender", "false");
    // Disable Java 9 Dpi scaling as XDM uses its own dpi scaling
    // System.setProperty("sun.java2d.uiScale.enabled", "true");
    // System.setProperty("sun.java2d.uiScale", "2.75");
  }

  public static void main(String[] args) {
    Logger.log("loading...");
    Logger.log(System.getProperty("java.version") + " " + System.getProperty("os.version"));

    System.setProperty("apple.awt.application.appearance", "system");
    System.setProperty("apple.laf.useScreenMenuBar", "true");
    System.setProperty("apple.awt.application.name", "XDM");

    FlatMacDarkLaf.setup();
    UIManager.put("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
    UIManager.put("SplitPaneDivider.gripDotCount", 0);
    // UIManager.put("Tree.selectionInsets", new Insets(5,5,5,5));
    //		UIManager.put("Tree.wideSelection", true);
    //		UIManager.put("Tree.selectionArc", 10);
    UIManager.put("SplitPane.dividerSize", 8);

//    XDMApp.start(args);
  }
}
