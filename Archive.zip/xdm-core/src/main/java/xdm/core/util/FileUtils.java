package xdm.core.util;

import java.util.Set;

public class FileUtils {
  private static final Set<Character> invalid_chars =
      CollectionUtils.setOf('/', '\\', '"', '?', '*', '<', '>', ':', '|');

  public static String sanitizeFileName(String name) {
    if (name == null) return null;
    char[] arr = name.toCharArray();
    for (int i = 0; i < arr.length; i++) {
      if (invalid_chars.contains(arr[i])) {
        arr[i] = '_';
      }
    }
    return new String(arr);
  }
}
