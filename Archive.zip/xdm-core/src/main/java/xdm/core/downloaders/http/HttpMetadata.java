package xdm.core.downloaders.http;

import lombok.Getter;
import lombok.Setter;
import xdm.core.downloaders.Metadata;
import xdm.core.network.http.HeaderCollection;

@Getter
@Setter
public class HttpMetadata extends Metadata {
  private String url;

  public HttpMetadata(
      String url,
      String cookies,
      HeaderCollection headers,
      String file,
      String contentType,
      boolean autoSelectFolder,
      String folder,
      long dateAdded,
      String originPage) {
    super(cookies, headers, file, contentType, autoSelectFolder, folder, dateAdded, originPage);
    this.url = url;
  }
}
