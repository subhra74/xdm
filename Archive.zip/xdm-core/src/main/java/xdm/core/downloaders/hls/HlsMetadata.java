package xdm.core.downloaders.hls;

import lombok.Getter;
import lombok.Setter;
import xdm.core.downloaders.Metadata;
import xdm.core.network.http.HeaderCollection;

@Getter
@Setter
public class HlsMetadata extends Metadata {
  private final String audioUrl;
  private final String url;

  public HlsMetadata(
      String url,
      String audioUrl,
      String cookies,
      HeaderCollection headers,
      String file,
      String contentType,
      boolean autoSelectFolder,
      String folder,
      long dateAdded,
      String originPage) {
    super(cookies, headers, file, contentType, autoSelectFolder, folder, dateAdded, originPage);
    this.url = url;
    this.audioUrl = audioUrl;
  }

  public boolean hasSeparateAudio() {
    return audioUrl != null;
  }
}
