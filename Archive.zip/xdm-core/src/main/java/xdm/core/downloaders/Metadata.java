package xdm.core.downloaders;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import xdm.core.network.http.HeaderCollection;

@Getter
@Setter
@AllArgsConstructor
public class Metadata {
  protected String cookies;
  protected HeaderCollection headers;
  protected String fileName;
  protected String contentType;
  protected boolean
      autoSelectFolder; // Download folder is set manually as opposed to category based one
  protected String folder;
  private long dateAdded;
  private String originPage;
}
