package xdm.core.downloaders;

import java.io.IOException;
import java.io.RandomAccessFile;

public interface Chunk {
  long getLastTakeOverTime();

  void setLastTakeOverTime(long time);

  public long getLength();

  public long getStartOffset();

  public long getDownloaded();

  public RandomAccessFile getOutStream();

  public boolean transferComplete() throws IOException;

  public void transferInitiated() throws IOException;

  public void transferring(int bytes);

  public void transferFailed(String reason);

  public boolean isFinished();

  public boolean isActive();

  public String getId();

  public void setId(String id);

  public void download(ChunkUpdateListener listenre) throws IOException;

  public void setLength(long length);

  public void setDownloaded(long downloaded);

  public void setStartOffset(long offset);

  public void stop();

  public ChunkUpdateListener getChunkListener();

  public void dispose();

  public AbstractChunkRetriever getChunkRetriever();

  public int getErrorCode();

  public Object getTag();

  public void setTag(Object obj);

  public void resetStream() throws IOException;

  public void reopenStream() throws IOException;

  public boolean promptCredential(String msg, boolean proxy);

  public void clearChannel();
}
