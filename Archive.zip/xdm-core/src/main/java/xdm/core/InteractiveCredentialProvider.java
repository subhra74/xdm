package xdm.core;

public interface InteractiveCredentialProvider {
  boolean promptCredential(String id, String msg, boolean proxy);
}
