use slint::{ComponentHandle, Model, ModelRc, SharedString, VecModel};
slint::include_modules!();

fn main() -> Result<(), slint::PlatformError> {
    println!("Hello");
    let items = vec![
        [
            "The quick brown fox jumped over the lazy dog",
            "/tmp",
            "60.5GB",
            "44.5GB",
        ],
        // ["網站有中", "網站有中", "網站有中", "82.2GB"],
        // ["敏捷的棕色狐狸跳過了懶狗", "/home", "255GB", "32.2GB"],
        // [
        //     "素早い茶色のキツネは怠け者の犬を飛び越えた",
        //     "/",
        //     "255GB",
        //     "82.2GB",
        // ],
        // [
        //     "재빠른 갈색 여우가 게으른 개를 뛰어넘었습니다.",
        //     "/tmp",
        //     "60.5GB",
        //     "44.5GB",
        // ],
        // [
        //     "قفز الثعلب البني السريع فوق الكلب الكسول",
        //     "/home",
        //     "255GB",
        //     "32.2GB",
        // ],
        // [
        //     "দ্রুত বাদামী শিয়ালটি অলস কুকুরটির উপর ঝাঁপিয়ে পড়ল।",
        //     "/",
        //     "255GB",
        //     "82.2GB",
        // ],
    ];

    let mut arr = Vec::new();

    for _ in 0..100000 {
        arr.append(&mut items.clone());
    }

    let ui = AppWindow::new()?;

    let v1: Vec<ContainerRecord> = arr
        .iter()
        .map(|arr| -> ContainerRecord {
            ContainerRecord {
                id: "string".into(),
                name: SharedString::from(arr[0]),
                image: "string".into(),
                state: "string".into(),
            }
        })
        .collect();

    let app_weak = ui.as_weak();

    let _thread = std::thread::spawn(move || {
        //std::thread::sleep(std::time::Duration::from_secs(5));
        let app_copy = app_weak.clone();
        //Expand the slint window from event loop
        slint::invoke_from_event_loop(move || {
            let mm: ModelRc<ContainerRecord> = ModelRc::new(VecModel::from(v1));
            app_copy.unwrap().set_values(mm);
        })
        .unwrap();

        //Another code that we wanted to execute after the application was launched
        //For example: hide the console window peculiar to slint
    });

    // run_event_loop()?;
    // Ok(())

    // let thread = std::thread::spawn(||{
    //     let containers = containers::list_containers();
    // });

    ui.run()
}
