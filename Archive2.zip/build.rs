fn main() {
    let config = slint_build::CompilerConfiguration::new()
        //.with_style("cupertino-dark".into());
        .with_style("fluent-dark".into());
        //.with_style("material-dark".into());
    slint_build::compile_with_config("ui/appwin.slint", config).unwrap();
}