package xdm.core.downloaders.http;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xdm.core.DownloadProgressListener;
import xdm.core.InteractiveCredentialProvider;
import xdm.core.XDMConstants;
import xdm.core.downloaders.AbstractChunkRetriever;
import xdm.core.downloaders.AbstractSegmentedDownloader;
import xdm.core.downloaders.Chunk;
import xdm.core.downloaders.DownloaderType;
import xdm.core.network.http.PoolingHttpClient;
import xdm.core.network.http.impl.PoolingHttpClientImpl;
import xdm.core.util.*;

public class HttpDownloader extends AbstractSegmentedDownloader {
  private final HttpMetadata metadata;
  private String newFileName;
  private final PoolingHttpClient httpClient;
  private static final Logger logger = LoggerFactory.getLogger(HttpDownloader.class);

  public HttpDownloader(
      long id,
      String tempFolder,
      HttpMetadata metadata,
      DownloadProgressListener listener,
      InteractiveCredentialProvider credentialProvider) {
    super(DownloaderType.Http, id, tempFolder, listener, credentialProvider);
    this.metadata = metadata;
    this.httpClient = new PoolingHttpClientImpl(100);
  }

  @Override
  public synchronized AbstractChunkRetriever createChannel(Chunk chunk) {
    return new HttpChunkRetriever(
        chunk, metadata.getUrl(), metadata.getHeaders(), length.get(), this.httpClient);
  }

  @Override
  public int getType() {
    return XDMConstants.HTTP;
  }

  @Override
  public boolean isFileNameChanged() {
    return newFileName != null;
  }

  @Override
  public String getNewFile() {
    return newFileName;
  }

  @Override
  protected void chunkConfirmed(Chunk c) {
    // logic
    // if the response has html content type and no attachment
    // no matter what is the target file extension, if any, will be changed to html.
    // If the download
    // has video conversion option, then conversion format will be removed.
    // in case of having an attachment, attachment extension will be used
    String oldFileName = getOutputFileName(false);
    HttpChunkRetriever hc = (HttpChunkRetriever) c.getChunkRetriever();
    super.getLastModifiedDate(c);
    if (hc.isRedirected()) {
      metadata.setUrl(hc.getRedirectUrl());
      MetadataIO.save(metadata);
    }

    String contentDispositionHeader = hc.getHeader("content-disposition");
    String contentType = hc.getHeader("content-type");

    if (contentDispositionHeader == null
        && StringUtils.containsIgnoreCase(contentType, "text/html")) {
      newFileName = XDMUtils.getFileNameWithoutExtension(oldFileName) + ".html";
      outputFormat = 0;
    }

    boolean nameSet = false;
    if (contentDispositionHeader != null && outputFormat == 0) {
      String name = NetUtils.getNameFromContentDisposition(contentDispositionHeader);
      if (name != null) {
        this.newFileName = name;
        nameSet = true;
        logger.info("set new filename: {}", newFileName);
      }
    }
    if (!nameSet) {
      String ext = XDMUtils.getExtension(oldFileName);
      if (StringUtils.isNullOrEmptyOrBlank(ext)) {
        String newExt = MimeUtil.getFileExt(contentType);
        if (newExt != null) {
          newFileName = oldFileName + "." + newExt;
        }
      }
      logger.info("new filename: {}", newFileName);
    }
  }

  @Override
  public HttpMetadata getMetadata() {
    return this.metadata;
  }
}
