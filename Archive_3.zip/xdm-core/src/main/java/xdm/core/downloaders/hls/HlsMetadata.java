package xdm.core.downloaders.hls;

import lombok.*;
import xdm.core.downloaders.Metadata;
import xdm.core.network.http.HeaderCollection;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HlsMetadata extends Metadata {
  private String audioUrl;
  private String url;

  //  public HlsMetadata(
  //      long id,
  //      String url,
  //      String audioUrl,
  //      String cookies,
  //      HeaderCollection headers,
  //      String file,
  //      String contentType,
  //      boolean autoSelectFolder,
  //      String folder,
  //      long dateAdded,
  //      String originPage) {
  //    super(id, cookies, headers, file, contentType, autoSelectFolder, folder, dateAdded,
  // originPage);
  //    this.url = url;
  //    this.audioUrl = audioUrl;
  //  }

  public boolean hasSeparateAudio() {
    return audioUrl != null;
  }

  @Override
  public String getPrimaryUrl() {
    return this.url;
  }
}
