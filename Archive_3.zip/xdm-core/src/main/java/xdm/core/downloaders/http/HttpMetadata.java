package xdm.core.downloaders.http;

import lombok.*;
import xdm.core.downloaders.Metadata;
import xdm.core.network.http.HeaderCollection;

@Data
public class HttpMetadata extends Metadata {
  private String url;

  @Builder
  public HttpMetadata(
      long id,
      String cookies,
      HeaderCollection headers,
      String fileName,
      String contentType,
      boolean autoSelectFolder,
      String folder,
      long dateAdded,
      String originPage,
      String url) {
    super(
        id,
        cookies,
        headers,
        fileName,
        contentType,
        autoSelectFolder,
        folder,
        dateAdded,
        originPage);
    this.url = url;
  }

  //  public HttpMetadata(
  //      long id,
  //      String url,
  //      String cookies,
  //      HeaderCollection headers,
  //      String file,
  //      String contentType,
  //      boolean autoSelectFolder,
  //      String folder,
  //      long dateAdded,
  //      String originPage) {
  //    super(id, cookies, headers, file, contentType, autoSelectFolder, folder, dateAdded,
  // originPage);
  //    this.url = url;
  //  }

  @Override
  public String getPrimaryUrl() {
    return this.url;
  }
}
