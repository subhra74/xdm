package xdm.core;

public interface DownloadProgressListener {
  public void downloadFinished(long id);

  public void downloadFailed(long id);

  public void downloadStopped(long id);

  public void downloadConfirmed(long id);

  public void downloadUpdated(long id);

  public String getOutputFolder(long id);

  public String getOutputFile(long id, boolean update);
}
