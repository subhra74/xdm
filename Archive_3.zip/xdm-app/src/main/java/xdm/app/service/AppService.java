package xdm.app.service;

public class AppService {}
