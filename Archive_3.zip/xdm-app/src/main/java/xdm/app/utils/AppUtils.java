package xdm.app.utils;

import com.formdev.flatlaf.extras.FlatSVGIcon;
import java.awt.*;
import java.io.IOException;

public class AppUtils {
  public static FlatSVGIcon createSVGIcon(String name, int size, Color color) {
    FlatSVGIcon.ColorFilter filter = new FlatSVGIcon.ColorFilter();
    filter.add(Color.BLACK, color);
    try {
      //var icon = new FlatSVGIcon(AppUtils.class.getResourceAsStream("/icons/" + name), size, size);
      var icon = new FlatSVGIcon("icons/" + name, size, size);
      icon.setColorFilter(filter);
      //return icon.derive(size, size);
      return icon;
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  public static FlatSVGIcon createSVGIcon(String name, int size) {
    try {
      var icon = new FlatSVGIcon(AppUtils.class.getResourceAsStream("/icons/" + name));
      return icon.derive(size, size);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
}
