package xdm.app.ui.components;

import lombok.AllArgsConstructor;
import xdm.app.models.DownloadEntry;

import java.util.Comparator;

@AllArgsConstructor
public class DownloadSorter implements Comparator<DownloadEntry> {
  private int column;

  @Override
  public int compare(DownloadEntry o1, DownloadEntry o2) {
    int res = 0;
    switch (column) {
      case 0: // sort by name
        res = o1.getFileName().compareTo(o2.getFileName());
        break;
      case 1: // sort by size
        res = o1.getSize() > o2.getSize() ? 1 : -1;
        break;
      case 2: // sort by date
        res = Long.compare(o1.getDateEpoch(), o2.getDateEpoch());
        break;
      case 3: // sort by type
        res = o1.getState().compareTo(o2.getState());
        break;
      case 4: // sort by type
        res = (int) (o1.getEta() - o2.getEta());
        break;
      case 5: // sort by type
        res = (int) (o1.getSpeed() - o2.getSpeed());
        break;
      default:
        break;
    }
    return res;
  }
}
