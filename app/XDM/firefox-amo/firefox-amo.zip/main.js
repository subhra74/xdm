"use strict";

const app = new App();
app.start();
