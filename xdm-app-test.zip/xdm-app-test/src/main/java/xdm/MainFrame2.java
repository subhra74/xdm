package xdm;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import xdm.utils.AppUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import java.awt.*;

public class MainFrame2 extends JFrame {
  public MainFrame2() {
    // Set the title of the window
    super("XDM Application");

    // Set the default close operation
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Set the size of the window
    setSize(800, 500);

    // Center the window on the screen
    setLocationRelativeTo(null);

    add(createToolBar(), BorderLayout.NORTH);
    add(createLeftPanel(), BorderLayout.WEST);
    add(createDownloadTable());

    // Make the window visible
    setVisible(true);
  }

  private Component createLeftPanel() {
    var tree = new JTree();
    tree.setCellRenderer(new DownloadTreeCellRenderer());
    var jsp = new JScrollPane(tree);
    jsp.setPreferredSize(new Dimension(180, 100));
    jsp.setBorder(new MatteBorder(0, 0, 0, 1, UIManager.getColor("Table.gridColor")));
    var p = new JPanel(new BorderLayout());
    p.add(jsp);
    p.setBorder(
        new CompoundBorder(new MatteBorder(1, 0, 0, 0, Color.BLACK), new EmptyBorder(0, 10, 0, 0)));
    p.setBackground(tree.getBackground());
    return p;
  }

  static class DownloadTreeCellRenderer implements TreeCellRenderer {

    @Override
    public Component getTreeCellRendererComponent(
        JTree tree,
        Object value,
        boolean selected,
        boolean expanded,
        boolean leaf,
        int row,
        boolean hasFocus) {
      var lbl = new JLabel("Some long");
      lbl.setIcon(AppUtils.createSVGIcon("file-zip-fill.svg", 20, Color.GRAY));
      lbl.setIconTextGap(10);
      lbl.setOpaque(true);
      lbl.setBackground(
          selected ? UIManager.getColor("Tree.selectionBackground") : tree.getBackground());
      lbl.setForeground(
          selected ? UIManager.getColor("Tree.selectionForeground") : tree.getForeground());
      lbl.setBorder(new EmptyBorder(5, 5, 5, 5));
      return lbl;
    }
  }

  private static Component leftList() {
    var box = Box.createVerticalBox();
    var lbl1 = new JLabel("Downloads");
    lbl1.setBorder(new EmptyBorder(0, 10, 5, 10));
    lbl1.setForeground(Color.GRAY);
    lbl1.setAlignmentX(0);
    box.add(lbl1);
    var model = new DefaultListModel<String>();
    model.addElement("Active");
    model.addElement("Finished");
    model.addElement("Failed");
    var list = new JList<String>(model);
    list.setCellRenderer(new LeftPanelCellRenderer());
    list.setAlignmentX(0);
    box.add(list);

    var model2 = new DefaultListModel<String>();
    model2.addElement("All files");
    model2.addElement("Documents");
    model2.addElement("Music");
    model2.addElement("Video");
    model2.addElement("Applications");
    model2.addElement("Zip files");
    var list2 = new JList<String>(model2);
    list2.setCellRenderer(new LeftPanelCellRenderer());
    list2.setAlignmentX(0);

    var lbl2 = new JLabel("Categories");
    lbl2.setBorder(new EmptyBorder(10, 10, 5, 10));
    lbl2.setForeground(Color.GRAY);
    lbl2.setAlignmentX(0);
    box.add(lbl2);
    box.add(list2);
    box.setBackground(list2.getBackground());
    box.setOpaque(true);
    box.setBorder(new EmptyBorder(10, 10, 10, 10));
    var jsp = new JScrollPane(box);
    jsp.setBorder(new MatteBorder(1, 0, 0, 1, UIManager.getColor("Table.gridColor")));

    //        var panel = new JPanel(new BorderLayout());
    //        var top = System.getProperty("hidetop") == null ? 10 : 5;
    //
    //        panel.setBorder(new EmptyBorder(top, 10, 10, 5));
    //        panel.add(jsp);
    return jsp;
  }

  private static JButton createToolButton(String icon, String text) {
    var btnNew = new JButton(text);
    btnNew.setIconTextGap(8);
    btnNew.setIcon(AppUtils.createSVGIcon(icon, 16, Color.GRAY));
    btnNew.setForeground(Color.GRAY);
    btnNew.setMargin(new Insets(5, 5, 5, 5));
    return btnNew;
  }

  static Component createDownloadTable() {
    var renderer = new DownloadTableCellRenderer();
    var model = new DownloadTableModel();
    var table = new JTable(model);
    table.setRowHeight(32);
    table.setDefaultRenderer(Object.class, renderer);
    table.setFillsViewportHeight(true);
    table.putClientProperty("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
    var headerRenderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(JLabel.LEFT);
    var jsp = new JScrollPane(table);
    jsp.setBorder(new MatteBorder(1, 0, 0, 0, Color.BLACK));
    jsp.setAutoscrolls(true);
    return jsp;
  }

  static Component createListTable() {
    var renderer = new DownloadListCellRenderer();
    var model = new DownloadListModel();
    var table = new JTable(model);
    table.setTableHeader(null);
    // table.setBackground(container.getBackground());
    table.setRowHeight(renderer.getHeight());
    table.setDefaultRenderer(Object.class, renderer);
    table.setFillsViewportHeight(true);
    var jsp = new JScrollPane(table);
    jsp.setBorder(new MatteBorder(1, 0, 0, 0, UIManager.getColor("Table.gridColor")));
    jsp.setAutoscrolls(true);
    // jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    return jsp;
  }

  private static Component rightPanel() {
    return createListTable();
  }

  private static Component createToolBar() {
    var toolbar = new JToolBar();
    toolbar.add(createToolButton("add-large-fill.svg", "New"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("pause-large-fill.svg", "Pause"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("delete-bin-line.svg", "Delete"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("sort-desc.svg", "Sort"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(Box.createHorizontalGlue());

    var txtSearch = new JTextField(12);
    txtSearch.putClientProperty("JTextField.placeholderText", "Search");
    txtSearch.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    txtSearch.putClientProperty(
        "JTextField.trailingIcon", AppUtils.createSVGIcon("search-line.svg", 16, Color.GRAY));
    // txtSearch.setFont(txtSearch.getFont().deriveFont(14.0f));
    var d = txtSearch.getPreferredSize();
    var d2 = new Dimension(d.width, d.height + 5);
    txtSearch.setMaximumSize(d2);
    txtSearch.setPreferredSize(d2);
    toolbar.add(txtSearch);

    toolbar.add(Box.createRigidArea(new Dimension(5, 10)));
    toolbar.add(createToolButton("menu-line.svg", null));
    toolbar.setBorder(new EmptyBorder(System.getProperty("hidetop") == null ? 5 : 5, 10, 5, 10));
    return toolbar;
  }

  static class DownloadTableModel extends AbstractTableModel {

    private String[] headers = new String[] {"Name", "Size", "Date", "%", "Status"};

    @Override
    public int getRowCount() {
      return 50;
    }

    @Override
    public int getColumnCount() {
      return 5;
    }

    @Override
    public String getColumnName(int column) {
      return headers[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
      return "hello";
    }
  }

  static class DownloadListModel extends AbstractTableModel {

    @Override
    public int getRowCount() {
      return 5;
    }

    @Override
    public int getColumnCount() {
      return 1;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
      return "hello";
    }
  }

  static class DownloadTableCellRenderer implements TableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
        JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      switch (column) {
        case 0:
          var lbl = new JLabel("Some long title name for testing");
          lbl.setIcon(AppUtils.createSVGIcon("file-zip-fill.svg", 20, Color.GRAY));
          lbl.setIconTextGap(10);
          lbl.setOpaque(true);
          lbl.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
          lbl.setBorder(new EmptyBorder(5, 10, 5, 5));
          return lbl;
        default:
          var lbl2 = new JLabel("Some text");
          lbl2.setOpaque(true);
          lbl2.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
          lbl2.setBorder(new EmptyBorder(5, 5, 5, 5));
          return lbl2;
      }
    }
  }

  static class DownloadListCellRenderer implements TableCellRenderer {
    private JPanel panel;

    public int getHeight() {
      return panel.getPreferredSize().height;
    }

    class RoundedBorder extends EmptyBorder {
      private Color corner;
      private Color line;

      public RoundedBorder(Color color, Color corner) {
        super(10, 10, 10, 10);
        this.line = color;
        this.corner = corner;
      }

      @Override
      public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        var g2 = (Graphics2D) g.create();
        g2.setStroke(new BasicStroke(10));
        g2.setPaint(Color.BLACK);
        g2.fillRect(x, y, width, height);
        g2.setStroke(new BasicStroke(10));
        g2.setPaint(Color.ORANGE);
        g2.drawRoundRect(x, y, width, height, 5, 5);
      }
    }

    DownloadListCellRenderer() {
      panel = new JPanel(new BorderLayout(8, 5));
      var p4 = new JPanel(new FlowLayout());
      p4.setOpaque(false);
      var p3 = new JPanel(new BorderLayout());
      p3.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
      p3.setBackground(Color.ORANGE);
      var icon = new JLabel(AppUtils.createSVGIcon("file-zip-fill.svg", 16, Color.WHITE));
      icon.setBorder(new EmptyBorder(5, 5, 5, 5));
      // icon.setOpaque(true);
      // icon.setBackground(Color.ORANGE);

      p3.add(icon);

      var chk = new JCheckBox();
      chk.setBorder(new EmptyBorder(0, 5, 0, 8));
      p4.add(chk);
      p4.add(p3);
      // p3.setBorder(new EmptyBorder(5,5,5,5));

      var content = new JPanel(new GridLayout(2, 1));
      content.setOpaque(false);
      var title = new JLabel("Some long title name for testing");
      title.setFont(title.getFont().deriveFont(12.0f));
      var statLabel =
          new JLabel("Downloaded 123MB of 378MB at 32.7MB/s ETA 01:33.03. Added on 13/02/2025");
      statLabel.setFont(statLabel.getFont().deriveFont(12.0f));
      statLabel.setForeground(Color.gray);

      content.add(title);
      content.add(statLabel);

      var p1 = new JPanel(new BorderLayout()); // new JPanel(new GridLayout(1, 2));
      var p5 = new JPanel();
      var prg = new JProgressBar();
      prg.setPreferredSize(new Dimension(60, 5));

      var p32 = Box.createVerticalBox();
      p32.setBorder(new EmptyBorder(0, 0, 0, 0));
      p32.add(new JLabel("Downloading.."));
      p32.add(Box.createRigidArea(new Dimension(5, 5)));
      p32.add(prg);

      p5.add(p32);
      p1.add(p5);

      var actions = Box.createHorizontalBox();
      actions.setBorder(new EmptyBorder(10, 10, 10, 10));
      actions.add(new JLabel(AppUtils.createSVGIcon("pause-circle-line.svg", 16, Color.GRAY)));
      actions.add(Box.createRigidArea(new Dimension(10, 10)));
      actions.add(new JLabel(AppUtils.createSVGIcon("delete-bin-line.svg", 16, Color.GRAY)));
      actions.add(Box.createRigidArea(new Dimension(5, 10)));
      // actions.add(new JLabel(AppUtils.createSVGIcon("more-2-fill.svg", 20, Color.GRAY)));

      p1.add(actions, BorderLayout.EAST);
      p1.setOpaque(false);
      p4.setOpaque(false);
      p5.setOpaque(false);

      panel.add(p4, BorderLayout.WEST);
      panel.add(content);
      panel.add(p1, BorderLayout.EAST);
      panel.setBorder(new EmptyBorder(10, 10, 0, 10));
    }

    @Override
    public Component getTableCellRendererComponent(
        JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      panel.setBackground(table.getBackground());
      return panel;
    }
  }

  static class LeftPanelCellRenderer implements ListCellRenderer<String> {

    @Override
    public Component getListCellRendererComponent(
        JList<? extends String> list,
        String value,
        int index,
        boolean isSelected,
        boolean cellHasFocus) {
      var label = new JLabel();
      label.setOpaque(true);
      label.setText(value);
      label.setIcon(AppUtils.createSVGIcon("arrow-up-down-fill.svg", 16, Color.GRAY));
      label.setIconTextGap(10);
      var color = isSelected ? list.getSelectionBackground() : list.getBackground();
      var lineBorder = new MatteBorder(0, 1, 0, 0, color);
      label.setBorder(new CompoundBorder(lineBorder, new EmptyBorder(10, 10, 10, 30)));
      label.setBackground(list.getBackground());
      label.setForeground(isSelected ? list.getSelectionForeground() : list.getForeground());
      return label;
    }
  }

  public static void main(String[] args) {
    System.setProperty("apple.awt.application.appearance", "system");
    FlatMacDarkLaf.setup();
    UIManager.put("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
    UIManager.put("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
    // UIManager.put("Tree.leftChildIndent", 20);

    // Run the application on the Event Dispatch Thread
    SwingUtilities.invokeLater(() -> new MainFrame2());
  }
}
