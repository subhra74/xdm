package xdm;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import java.awt.*;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import com.formdev.flatlaf.ui.FlatBorder;
import com.formdev.flatlaf.ui.FlatRoundBorder;
import com.formdev.flatlaf.util.SystemInfo;
import xdm.utils.AppUtils;

public class MainFrame extends JFrame {
  public MainFrame() {
    // Set the title of the window
    super("XDM");

    // Set the default close operation
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Set the size of the window
    setSize(800, 500);

    // Center the window on the screen
    setLocationRelativeTo(null);

    add(leftList(), BorderLayout.WEST);
    add(rightPanel());

    // Make the window visible
    setVisible(true);
  }

  //  private Component createLeftPanel() {
  //    var jpanel = new JPanel(new BorderLayout());
  //    var tree = new JTree();
  //    tree.setCellRenderer(new DownloadTreeCellRenderer());
  //    var jsp = new JScrollPane(tree);
  //    jsp.setPreferredSize(new Dimension(180, 100));
  //    jsp.setBorder(new EmptyBorder(0, 0, 0, 0));
  //    // jpanel.setBorder(new EmptyBorder(10, 10, 10, 0));
  //    jpanel.add(jsp);
  //    return jpanel;
  //  }

  //  static class DownloadTreeCellRenderer implements TreeCellRenderer {
  //
  //    @Override
  //    public Component getTreeCellRendererComponent(
  //        JTree tree,
  //        Object value,
  //        boolean selected,
  //        boolean expanded,
  //        boolean leaf,
  //        int row,
  //        boolean hasFocus) {
  //      var lbl = new JLabel("Some long");
  //      lbl.setIcon(AppUtils.createSVGIcon("file-zip-fill.svg", 20, Color.GRAY));
  //      lbl.setIconTextGap(10);
  //      lbl.setOpaque(true);
  //      lbl.setBackground(
  //          selected ? UIManager.getColor("Tree.selectionBackground") : tree.getBackground());
  //      lbl.setForeground(
  //          selected ? UIManager.getColor("Tree.selectionForeground") : tree.getForeground());
  //      lbl.setBorder(new EmptyBorder(5, 5, 5, 5));
  //      return lbl;
  //    }
  //  }

  private static Component leftList() {
    var panel = new JPanel(new BorderLayout());

    var p1 = new JPanel(new BorderLayout());
    var p2 = new JPanel(new BorderLayout());

    var lbl1 = new JLabel("Downloads");
    lbl1.setAlignmentX(Component.LEFT_ALIGNMENT);
    lbl1.setBorder(new EmptyBorder(0, 10, 10, 10));
    lbl1.setForeground(Color.GRAY);
    lbl1.setAlignmentX(Component.LEFT_ALIGNMENT);

    var model = new DefaultListModel<String>();
    model.addElement("Active");
    model.addElement("Finished");
    model.addElement("Failed");
    var list = new JList<String>(model);
    list.setCellRenderer(new LeftPanelCellRenderer());

    p1.add(lbl1, BorderLayout.NORTH);
    p1.add(list);

    var model2 = new DefaultListModel<String>();
    model2.addElement("All files");
    model2.addElement("Documents");
    model2.addElement("Music");
    model2.addElement("Video");
    model2.addElement("Applications");
    model2.addElement("Zip files");
    var list2 = new JList<String>(model2);
    list2.setCellRenderer(new LeftPanelCellRenderer());
    list2.setBackground(UIManager.getColor("Panel.background"));

    var lbl2 = new JLabel("Categories");
    lbl2.setAlignmentX(Component.LEFT_ALIGNMENT);
    lbl2.setBorder(new EmptyBorder(10, 10, 10, 10));
    lbl2.setForeground(Color.GRAY);
    lbl2.setAlignmentX(Component.LEFT_ALIGNMENT);

    p2.add(lbl2, BorderLayout.NORTH);
    p2.add(list2);

    panel.add(p1, BorderLayout.NORTH);
    panel.add(p2);
    panel.setBorder(new EmptyBorder(10, 15, 10, 5));
    var jsp = new JScrollPane(panel);
    jsp.setBorder(new EmptyBorder(0, 0, 0, 0));
    jsp.setOpaque(false);
    return jsp;
  }

  //  private static Component leftList2() {
  //    var box = Box.createVerticalBox();
  //    var lbl1 = new JLabel("Downloads");
  //    lbl1.setAlignmentX(Component.LEFT_ALIGNMENT);
  //    lbl1.setBorder(new EmptyBorder(0, 10, 10, 10));
  //    lbl1.setForeground(Color.GRAY);
  //    lbl1.setAlignmentX(Component.LEFT_ALIGNMENT);
  //    box.add(lbl1);
  //    var model = new DefaultListModel<String>();
  //    model.addElement("Active");
  //    model.addElement("Finished");
  //    model.addElement("Failed");
  //    var list = new JList<String>(model);
  //    list.setAlignmentX(Component.LEFT_ALIGNMENT);
  //    list.setOpaque(false);
  //    list.setCellRenderer(new LeftPanelCellRenderer());
  //    list.setAlignmentX(Component.LEFT_ALIGNMENT);
  //
  //    var model2 = new DefaultListModel<String>();
  //    model2.addElement("All files");
  //    model2.addElement("Documents");
  //    model2.addElement("Music");
  //    model2.addElement("Video");
  //    model2.addElement("Applications");
  //    model2.addElement("Zip files");
  //    var list2 = new JList<String>(model2);
  //    list2.setOpaque(false);
  //    list2.setCellRenderer(new LeftPanelCellRenderer());
  //    list2.setAlignmentX(Component.LEFT_ALIGNMENT);
  //
  //    var lbl2 = new JLabel("Categories");
  //    lbl2.setAlignmentX(Component.LEFT_ALIGNMENT);
  //    lbl2.setBorder(new EmptyBorder(10, 10, 10, 10));
  //    lbl2.setForeground(Color.GRAY);
  //    lbl2.setAlignmentX(Component.LEFT_ALIGNMENT);
  //
  //    var d1 = list.getPreferredSize();
  //    var d2 = list2.getPreferredSize();
  //
  //    var width = Math.max(d1.width, d2.width);
  //
  //    var d3 = new Dimension(width, d1.height);
  //    var d4 = new Dimension(width, d2.height);
  //    list.setPreferredSize(d3);
  //    list.setMinimumSize(d3);
  //    list.setMaximumSize(d3);
  //    list2.setPreferredSize(d4);
  //    list2.setMinimumSize(d4);
  //    list2.setMaximumSize(d4);
  //
  //    box.add(list);
  //    box.add(lbl2);
  //    box.add(list2);
  //    // box.setBackground(list2.getBackground());
  //    // box.setOpaque(true);
  //    box.setBorder(new EmptyBorder(10, 10, 10, 10));
  //    var jsp = new JScrollPane(box);
  //    jsp.setBorder(new EmptyBorder(0, 0, 0, 0));
  //    jsp.setOpaque(false);
  //    // jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
  //
  //    var panel = new JPanel(new BorderLayout());
  //    var top = System.getProperty("hidetop") == null ? 10 : 5;
  //
  //    // panel.setBorder(new EmptyBorder(0, 0, 0, 0));
  //    //    panel.setBorder(
  //    //            new CompoundBorder(
  //    //                    new MatteBorder(1, 0, 0, 1,
  // UIManager.getColor("Component.borderColor")),
  //    //                    new EmptyBorder(0, 0, 0, 0)));
  //    //    panel.setBorder(
  //    //        new CompoundBorder(new MatteBorder(1, 0, 0, 1, Color.BLACK), new EmptyBorder(0, 0,
  // 0,
  //    // 0)));
  //    panel.setBorder(new EmptyBorder(0, 0, 0, 0));
  //    panel.add(jsp);
  //    return panel;
  //  }

  private static JButton createToolButton(String icon, String text) {
    var btnNew = new JButton(text);
    btnNew.setIconTextGap(5);
    btnNew.setIcon(AppUtils.createSVGIcon(icon, 16, Color.GRAY));
    btnNew.setForeground(Color.GRAY);
    btnNew.setMargin(new Insets(5, 5, 5, 5));
    return btnNew;
  }

  //  static Component createDownloadTable(JPanel container) {
  //    var renderer = new DownloadTableCellRenderer();
  //    var model = new DownloadTableModel();
  //    var table = new JTable(model);
  //    table.setRowHeight(32);
  //    table.setDefaultRenderer(Object.class, renderer);
  //    table.setFillsViewportHeight(true);
  //    table.putClientProperty("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
  //    var headerRenderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
  //    headerRenderer.setHorizontalAlignment(JLabel.LEFT);
  //    var jsp = new JScrollPane(table);
  //    jsp.setAutoscrolls(true);
  //    return jsp;
  //  }

  static Component createListTable(JPanel container) {
    var renderer = new DownloadListCellRenderer();
    var model = new DownloadListModel();
    var table = new JTable(model);
    table.setTableHeader(null);
    table.setBackground(container.getBackground());
    table.setRowHeight(renderer.getHeight());
    table.setDefaultRenderer(Object.class, renderer);
    table.setFillsViewportHeight(true);
    var jsp = new JScrollPane(table);
    jsp.setBorder(new EmptyBorder(0, 0, 0, 0));
    jsp.setAutoscrolls(true);
    // jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    return jsp;
  }

  private static Component rightPanel() {
    var panel = new JPanel(new BorderLayout(0, 0));

    panel.add(createListTable(panel));
    // panel.add(createDownloadTable(panel));

    var toolbar = new JToolBar();
    toolbar.add(createToolButton("add-large-fill.svg", "New"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("pause-large-fill.svg", "Pause"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("delete-bin-line.svg", "Delete"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("sort-desc.svg", "Sort"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(Box.createHorizontalGlue());

    var txtSearch = new JTextField(12);
    txtSearch.putClientProperty("JTextField.placeholderText", "Search");
    txtSearch.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    txtSearch.putClientProperty(
        "JTextField.trailingIcon", AppUtils.createSVGIcon("search-line.svg", 16, Color.GRAY));
    // txtSearch.setFont(txtSearch.getFont().deriveFont(14.0f));
    var d = txtSearch.getPreferredSize();
    var d2 = new Dimension(d.width, d.height + 5);
    txtSearch.setMaximumSize(d2);
    txtSearch.setPreferredSize(d2);
    toolbar.add(txtSearch);

    toolbar.add(Box.createRigidArea(new Dimension(5, 10)));
    toolbar.add(createToolButton("menu-line.svg", null));
    toolbar.setBorder(new EmptyBorder(5, 0, 0, 10));

    panel.add(toolbar, BorderLayout.NORTH);
    //    panel.setBorder(
    //        new CompoundBorder(
    //            new MatteBorder(1, 0, 0, 0, UIManager.getColor("Component.borderColor")),
    //            new EmptyBorder(2, 5, 0, 0)));
    panel.setBorder(new EmptyBorder(2, 5, 0, 0));
    //    panel.setBorder(
    //            new CompoundBorder(
    //                    new MatteBorder(1, 0, 0, 0, Color.BLACK),
    //                    new EmptyBorder(2, 5, 0, 0)));
    return panel;
  }

  //  static class DownloadTableModel extends AbstractTableModel {
  //
  //    private String[] headers = new String[] {"Name", "Size", "Date", "%", "Status"};
  //
  //    @Override
  //    public int getRowCount() {
  //      return 50;
  //    }
  //
  //    @Override
  //    public int getColumnCount() {
  //      return 5;
  //    }
  //
  //    @Override
  //    public String getColumnName(int column) {
  //      return headers[column];
  //    }
  //
  //    @Override
  //    public Object getValueAt(int rowIndex, int columnIndex) {
  //      return "hello";
  //    }
  //  }

  static class DownloadListModel extends AbstractTableModel {

    @Override
    public int getRowCount() {
      return 5;
    }

    @Override
    public int getColumnCount() {
      return 1;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
      return "hello";
    }
  }

  //  static class DownloadTableCellRenderer implements TableCellRenderer {
  //
  //    @Override
  //    public Component getTableCellRendererComponent(
  //        JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
  //      switch (column) {
  //        case 0:
  //          var lbl = new JLabel("Some long title name for testing");
  //          lbl.setIcon(AppUtils.createSVGIcon("file-zip-fill.svg", 24, Color.GRAY));
  //          lbl.setIconTextGap(10);
  //          lbl.setOpaque(true);
  //          lbl.setBackground(isSelected ? table.getSelectionBackground() :
  // table.getBackground());
  //          lbl.setBorder(new EmptyBorder(5, 10, 5, 5));
  //          return lbl;
  //        default:
  //          var lbl2 = new JLabel("Some text");
  //          lbl2.setOpaque(true);
  //          lbl2.setBackground(isSelected ? table.getSelectionBackground() :
  // table.getBackground());
  //          lbl2.setBorder(new EmptyBorder(5, 5, 5, 5));
  //          return lbl2;
  //      }
  //    }
  //  }

  //  static Component createDownloadTable(JPanel container) {
  //    var renderer = new MainFrame3.DownloadTableCellRenderer();
  //    var model = new MainFrame3.DownloadTableModel();
  //    var table = new JTable();
  //    table.setModel(model);
  //
  //    table.setRowHeight(32);
  //    table.setDefaultRenderer(Object.class, renderer);
  //    table.setFillsViewportHeight(true);
  //    table.putClientProperty("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
  //    var headerRenderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
  //    headerRenderer.setHorizontalAlignment(JLabel.LEFT);
  //    var jsp = new JScrollPane(table);
  //    jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
  //    jsp.setAutoscrolls(true);
  //    return jsp;
  //  }

  static class DownloadListCellRenderer implements TableCellRenderer {
    private JPanel panel;
    private JLabel lblSize, lblDate, lblSpeed, lblEta;
    private Component prgDetails;
    private Component lblDetails;

    public int getHeight() {
      return panel.getPreferredSize().height;
    }

    private JLabel createStatusLabel(String iconName, String text, Font font) {
      var l1 = new JLabel(AppUtils.createSVGIcon(iconName, 12, Color.GRAY));
      l1.setFont(font);
      l1.setForeground(Color.GRAY);
      l1.setText(text);
      return l1;
    }

    DownloadListCellRenderer() {
      panel = new JPanel(new BorderLayout(8, 5));
      var p4 = new JPanel(new FlowLayout());
      p4.setOpaque(false);
      var p3 = new JPanel(new BorderLayout());
      p3.putClientProperty(FlatClientProperties.STYLE, "arc: 8");
      p3.setBackground(new Color(30, 144, 255));
      var icon = new JLabel(AppUtils.createSVGIcon("file-zip-fill.svg", 20, Color.WHITE));
      icon.setBorder(new EmptyBorder(5, 5, 5, 5));
      // icon.setOpaque(true);
      // icon.setBackground(Color.ORANGE);

      p3.add(icon);

      var chk = new JCheckBox();
      chk.setBorder(new EmptyBorder(0, 0, 0, 8));
      p4.add(chk);
      p4.add(p3);
      // p3.setBorder(new EmptyBorder(5,5,5,5));

      var content = new JPanel(new GridLayout(2, 1, 0, 0));
      content.setOpaque(false);
      var title = new JLabel("Some long title name for testing");
      title.setVerticalAlignment(JLabel.BOTTOM);
      // title.setFont(title.getFont().deriveFont(12.0f));
      var pp = Box.createHorizontalBox();

      var fnt = title.getFont().deriveFont(12.0f);

      lblSize = createStatusLabel("arrow-down-line.svg", "234M / 456M", fnt);
      lblDate = createStatusLabel("calendar-line.svg", "June 24", fnt);
      lblSpeed = createStatusLabel("line-chart-line.svg", "6.5MB/s", fnt);
      lblEta = createStatusLabel("timer-line.svg", "00:02:34", fnt);

      pp.add(lblSize);
      pp.add(Box.createRigidArea(new Dimension(10, 5)));
      pp.add(lblDate);
      pp.add(Box.createRigidArea(new Dimension(10, 5)));
      pp.add(lblEta);
      pp.add(Box.createRigidArea(new Dimension(10, 5)));
      pp.add(lblSpeed);
      pp.add(Box.createRigidArea(new Dimension(10, 5)));

      var statLabel = new JLabel("Downloading 378 M at 2.6 MB/s ETA 00:02:56");
      statLabel.setVerticalAlignment(JLabel.TOP);
      // statLabel.setFont(statLabel.getFont().deriveFont(12.0f));
      statLabel.setForeground(Color.gray);

      content.add(title);
      content.add(pp);

      var p1 = new JPanel(new BorderLayout()); // new JPanel(new GridLayout(1, 2));
      var p5 = new JPanel();
      var prg = new JProgressBar();
      prg.setPreferredSize(new Dimension(50, 5));
      prg.setAlignmentY(Component.CENTER_ALIGNMENT);
      // prg.setMaximumSize(new Dimension(120, 5));

      var prgDetails = Box.createVerticalBox();
      // p32.add(Box.createVerticalGlue());
      prgDetails.setBorder(new EmptyBorder(0, 0, 0, 0));
      var l32 = new JLabel("30%");
      l32.setHorizontalAlignment(JLabel.CENTER);
      l32.setHorizontalTextPosition(JLabel.CENTER);
      // l32.setFont(title.getFont().deriveFont(11.0f));
      prgDetails.add(l32);
      // p32.add(Box.createRigidArea(new Dimension(5, 5)));
      prgDetails.add(prg);

      this.prgDetails = prgDetails;
      // p32.add(Box.createVerticalGlue());
      // p32.add(Box.createRigidArea(new Dimension(5, 2)));
      // var l64 = new JLabel("Downloading..");
      // l64.setFont(title.getFont().deriveFont(11.0f));
      // p32.add(l64);
      this.lblDetails = new JLabel("Complete");
      p5.add(prgDetails);
      p5.add(lblDetails);
      p1.add(p5);

      var actions = Box.createHorizontalBox();
      actions.setBorder(new EmptyBorder(10, 10, 10, 10));
      actions.add(new JLabel(AppUtils.createSVGIcon("pause-circle-line.svg", 16, Color.GRAY)));
      actions.add(Box.createRigidArea(new Dimension(10, 10)));
      actions.add(new JLabel(AppUtils.createSVGIcon("delete-bin-line.svg", 16, Color.GRAY)));
      actions.add(Box.createRigidArea(new Dimension(5, 10)));
      // actions.add(new JLabel(AppUtils.createSVGIcon("more-2-fill.svg", 20, Color.GRAY)));

      p1.add(actions, BorderLayout.EAST);
      p1.setOpaque(false);
      p4.setOpaque(false);
      p5.setOpaque(false);

      panel.add(p4, BorderLayout.WEST);
      panel.add(content);
      panel.add(p1, BorderLayout.EAST);
      panel.setBorder(new EmptyBorder(5, 0, 0, 0));
    }

    @Override
    public Component getTableCellRendererComponent(
        JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      if (row % 2 == 0 || row % 3 == 0) {
        lblSpeed.setVisible(false);
        lblEta.setVisible(false);
        prgDetails.setVisible(false);
        lblDetails.setVisible(true);
      } else {
        lblSpeed.setVisible(true);
        lblEta.setVisible(true);
        prgDetails.setVisible(true);
        lblDetails.setVisible(false);
      }
      panel.setBackground(table.getBackground());
      return panel;
    }
  }

  static class LeftPanelCellRenderer implements ListCellRenderer<String> {

    @Override
    public Component getListCellRendererComponent(
        JList<? extends String> list,
        String value,
        int index,
        boolean isSelected,
        boolean cellHasFocus) {
      var label = new JLabel();
      label.putClientProperty(FlatClientProperties.STYLE, "arc: 8");
      label.setText(value);
      label.setIcon(AppUtils.createSVGIcon("arrow-up-down-fill.svg", 20, Color.GRAY));
      label.setIconTextGap(10);
      // var color = isSelected ? list.getSelectionBackground() : list.getBackground();
      // var lineBorder = new MatteBorder(0, 1, 0, 0, color);
      // label.setBorder(new CompoundBorder(lineBorder, new EmptyBorder(10, 10, 10, 30)));
      label.setBorder(new EmptyBorder(5, 10, 5, 30));
      label.setOpaque(true);
      label.setBackground(
          isSelected ? list.getSelectionBackground() : UIManager.getColor("Panel.background"));
      label.setForeground(isSelected ? list.getSelectionForeground() : list.getForeground());
      return label;
    }
  }

  static {
    System.setProperty("awt.toolkit.name", "WLToolkit");
  }

  public static void main(String[] args) {
    System.setProperty("apple.awt.application.appearance", "system");
    //    if(SystemInfo.isLinux){
    //      JFrame.setDefaultLookAndFeelDecorated( true );
    //      JDialog.setDefaultLookAndFeelDecorated( true );
    //    }
    if (args.length > 1 && args[0].equalsIgnoreCase("skip_theme")) {
      System.out.println("Skipping flatlaf");
      //UIManager.setLookAndFeel();
    }else{
      FlatMacDarkLaf.setup();
    }
    UIManager.put("TableHeader.cellMargins", new Insets(0, 10, 0, 0));

    // Run the application on the Event Dispatch Thread
    SwingUtilities.invokeLater(() -> new MainFrame3());
  }
}
