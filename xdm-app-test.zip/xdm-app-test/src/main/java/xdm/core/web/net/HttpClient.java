package xdm.core.web.net;

public interface HttpClient {

}
