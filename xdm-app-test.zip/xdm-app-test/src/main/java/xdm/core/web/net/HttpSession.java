package xdm.core.web.net;

public interface HttpSession {
    void close();
    void addHeader(String name,String value);
    void addHeaders(String name,String value);
}
