package xdm;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import java.awt.*;
import java.util.List;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import com.formdev.flatlaf.ui.FlatBorder;
import com.formdev.flatlaf.ui.FlatRoundBorder;
import com.formdev.flatlaf.util.StringUtils;
import com.formdev.flatlaf.util.SystemInfo;
import xdm.utils.AppUtils;

public class MainFrame3 extends JFrame {
  public MainFrame3() {
    // Set the title of the window
    super("XDM Application");

    // Set the default close operation
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Set the size of the window
    setSize(800, 500);

    // Center the window on the screen
    setLocationRelativeTo(null);

    add(createLeftPanel(), BorderLayout.WEST);
    add(rightPanel());

    // Make the window visible
    setVisible(true);
  }

  private Component createLeftPanel() {
    var jpanel = new JPanel(new BorderLayout());
    var tree = new JTree();
    tree.setCellRenderer(new DownloadTreeCellRenderer());
    var jsp = new JScrollPane(tree);
    jsp.setPreferredSize(new Dimension(180, 100));
    //jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    // jsp.setBorder(new EmptyBorder(0, 0, 0, 0));
    jpanel.setBorder(new EmptyBorder(SystemInfo.isWindows ? 5 : 10, 10, 10, 0));
    jpanel.add(jsp);
    return jpanel;
  }

  static class DownloadTreeCellRenderer implements TreeCellRenderer {

    @Override
    public Component getTreeCellRendererComponent(
        JTree tree,
        Object value,
        boolean selected,
        boolean expanded,
        boolean leaf,
        int row,
        boolean hasFocus) {
      var lbl = new JLabel("Some long");
      lbl.setIcon(AppUtils.createSVGIcon("file-zip-fill.svg", 20, Color.GRAY));
      lbl.setIconTextGap(10);
      lbl.setOpaque(true);
      lbl.setBackground(
          selected ? UIManager.getColor("Tree.selectionBackground") : tree.getBackground());
      lbl.setForeground(
          selected ? UIManager.getColor("Tree.selectionForeground") : tree.getForeground());
      lbl.setBorder(new EmptyBorder(5, 5, 5, 5));
      return lbl;
    }
  }

  //  private static Component leftList() {
  //    var box = Box.createVerticalBox();
  //    var lbl1 = new JLabel("Downloads");
  //    lbl1.setBorder(new EmptyBorder(0, 10, 5, 10));
  //    lbl1.setForeground(Color.GRAY);
  //    lbl1.setAlignmentX(0);
  //    box.add(lbl1);
  //    var model = new DefaultListModel<String>();
  //    model.addElement("Active");
  //    model.addElement("Finished");
  //    model.addElement("Failed");
  //    var list = new JList<String>(model);
  //    list.setCellRenderer(new LeftPanelCellRenderer());
  //    list.setAlignmentX(0);
  //    box.add(list);
  //
  //    var model2 = new DefaultListModel<String>();
  //    model2.addElement("All files");
  //    model2.addElement("Documents");
  //    model2.addElement("Music");
  //    model2.addElement("Video");
  //    model2.addElement("Applications");
  //    model2.addElement("Zip files");
  //    var list2 = new JList<String>(model2);
  //    list2.setCellRenderer(new LeftPanelCellRenderer());
  //    list2.setAlignmentX(0);
  //
  //    var lbl2 = new JLabel("Categories");
  //    lbl2.setBorder(new EmptyBorder(10, 10, 5, 10));
  //    lbl2.setForeground(Color.GRAY);
  //    lbl2.setAlignmentX(0);
  //    box.add(lbl2);
  //    box.add(list2);
  //    box.setBackground(list2.getBackground());
  //    box.setOpaque(true);
  //    box.setBorder(new EmptyBorder(10, 10, 10, 10));
  //    var jsp = new JScrollPane(box);
  //    jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
  //
  //    var panel = new JPanel(new BorderLayout());
  //    var top = System.getProperty("hidetop") == null ? 10 : 5;
  //
  //    panel.setBorder(new EmptyBorder(top, 10, 10, 5));
  //    panel.add(jsp);
  //    return panel;
  //  }

  private static JButton createToolButton(String icon, String text) {
    var btnNew = new JButton(text);
    btnNew.setIconTextGap(8);
    btnNew.setIcon(AppUtils.createSVGIcon(icon, 16, Color.GRAY));
    btnNew.setForeground(Color.GRAY);
    btnNew.setMargin(new Insets(5, 5, 5, 5));
    return btnNew;
  }

  static Component createDownloadTable(JPanel container) {
    var renderer = new DownloadTableCellRenderer();
    var model = new DownloadTableModel();
    var table = new JTable();
    table.setModel(model);

    table.setRowHeight(32);
    table.setDefaultRenderer(Object.class, renderer);
    table.setFillsViewportHeight(true);
    table.putClientProperty("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
    var headerRenderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(JLabel.LEFT);
    var jsp = new JScrollPane(table);
   // jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    jsp.setAutoscrolls(true);
    return jsp;
  }

  //  static Component createListTable(JPanel container) {
  //    var renderer = new DownloadListCellRenderer();
  //    var model = new DownloadListModel();
  //    var table = new JTable(model);
  //    table.setTableHeader(null);
  //    // table.setBackground(container.getBackground());
  //    table.setRowHeight(renderer.getHeight());
  //    table.setDefaultRenderer(Object.class, renderer);
  //    table.setFillsViewportHeight(true);
  //    var jsp = new JScrollPane(table);
  //    // jsp.setBorder(new EmptyBorder(0, 0, 0, 0));
  //    jsp.setAutoscrolls(true);
      //jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
  //    return jsp;
  //  }

  private static Component rightPanel() {
    var panel = new JPanel(new BorderLayout(10, 5));

    // panel.add(createListTable(panel));
    panel.add(createDownloadTable(panel));

    var toolbar = new JToolBar();
    var button = createToolButton("add-large-fill.svg", "New");
    button.addActionListener(
        e -> {
          new Test().test();
        });
    toolbar.add(button);
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("pause-large-fill.svg", "Pause"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("delete-bin-line.svg", "Delete"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("sort-desc.svg", "Sort"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(Box.createHorizontalGlue());

    var txtSearch = new JTextField(12);
    txtSearch.putClientProperty("JTextField.placeholderText", "Search");
    //txtSearch.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    txtSearch.putClientProperty(
        "JTextField.trailingIcon", AppUtils.createSVGIcon("search-line.svg", 16, Color.GRAY));
    // txtSearch.setFont(txtSearch.getFont().deriveFont(14.0f));
    var d = txtSearch.getPreferredSize();
    var d2 = new Dimension(d.width, d.height + 5);
    txtSearch.setMaximumSize(d2);
    txtSearch.setPreferredSize(d2);
    toolbar.add(txtSearch);

    toolbar.add(Box.createRigidArea(new Dimension(5, 10)));
    toolbar.add(createToolButton("menu-line.svg", null));
    if (SystemInfo.isWindows) {
      toolbar.setBorder(new EmptyBorder(5, 0, 0, 0));
    } else {
      toolbar.setBorder(new EmptyBorder(10, 0, 0, 0));
    }
    // toolbar.setBorder(new EmptyBorder(System.getProperty("hidetop") == null ? 10 : 5, 0, 0, 0));

    panel.add(toolbar, BorderLayout.NORTH);
    panel.setBorder(new EmptyBorder(0, 10, 10, 10));
    return panel;
  }

  static class DownloadTableModel extends AbstractTableModel {

    private String[] headers = new String[] {"Name", "Size", "Date", "Status", "ETA", "Speed"};

    @Override
    public int getRowCount() {
      return 91;
    }

    @Override
    public int getColumnCount() {
      return 6;
    }

    @Override
    public String getColumnName(int column) {
      return headers[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
      return "hello";
    }
  }

  //  static class DownloadListModel extends AbstractTableModel {
  //
  //    @Override
  //    public int getRowCount() {
  //      return 5;
  //    }
  //
  //    @Override
  //    public int getColumnCount() {
  //      return 1;
  //    }
  //
  //    @Override
  //    public Object getValueAt(int rowIndex, int columnIndex) {
  //      return "hello";
  //    }
  //  }

  static class DownloadTableCellRenderer implements TableCellRenderer {
    private JLabel lbl, lbl2;
    private Font font;
    private Font fontBkp;

    public DownloadTableCellRenderer() {
      try {
        if (!StringUtils.isEmpty(System.getenv("CUSTOM_FONT_NAME"))) {
          font = new Font(System.getenv("CUSTOM_FONT_NAME"), Font.PLAIN, 12);
        } else {
          font =
              Font.createFont(
                      Font.TRUETYPE_FONT,
                      getClass().getResourceAsStream("/font/unifont-16.0.03.otf"))
                  .deriveFont(Font.PLAIN, 12.0f);
        }
      } catch (Exception ex) {
        ex.printStackTrace();
      }

      lbl = new JLabel();
      fontBkp = lbl.getFont();
      if (!StringUtils.isEmpty(System.getenv("USE_CUSTOM_FONT"))) {
        fontBkp = new Font(System.getenv("CUSTOM_FONT_NAME"), Font.PLAIN, 12);
      }
      lbl.setIcon(AppUtils.createSVGIcon("file-zip-fill.svg", 20, Color.GRAY));
      lbl.setIconTextGap(10);
      lbl.setOpaque(true);
      lbl.setBorder(new EmptyBorder(5, 10, 5, 5));

      lbl2 = new JLabel("Some text");
      lbl2.setOpaque(true);
      lbl2.setBorder(new EmptyBorder(5, 5, 5, 5));

      //      try {
      //        font =
      //            Font.createFont(
      //                    Font.TRUETYPE_FONT,
      //                    getClass()
      //                        .getResourceAsStream(
      // "/font/unifont-16.0.03.otf"
      //                            ))
      //                .deriveFont(Font.PLAIN, 12.0f);
      //        fontBkp = font;
      //      } catch (Exception ex) {
      //        ex.printStackTrace();
      //      }
    }

    List<String> texts =
        List.of(
            "The quick brown fox jumped over the lazy dog",
            "敏捷的棕色狐狸跳過了懶狗",
            "素早い茶色のキツネは怠け者の犬を飛び越えた",
            "재빠른 갈색 여우가 게으른 개를 뛰어넘었습니다.",
            "قفز الثعلب البني السريع فوق الكلب الكسول",
            "দ্রুত বাদামী শিয়ালটি অলস কুকুরটির উপর ঝাঁপিয়ে পড়ল।");

    private String getText(int index) {
      if (index % 9 == 0) {
        return texts.get(4);
      }
      if (index % 4 == 0) {
        return texts.get(5);
      }
      if (index % 3 == 0) {
        return texts.get(1);
      }
      if (index % 5 == 0) {
        return texts.get(2);
      }
      if (index % 7 == 0) {
        return texts.get(3);
      }
      return texts.get(0);
    }

    @Override
    public Component getTableCellRendererComponent(
        JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      switch (column) {
        case 0:
          var text = getText(row);
          if (fontBkp.canDisplayUpTo(text) == -1) {
            lbl.setFont(fontBkp);
            System.out.println("Using default font");
          } else {
            lbl.setFont(font);
            System.out.println("Using gnu font");
          }
          lbl.setText(text);
          lbl.setIconTextGap(10);
          lbl.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
          return lbl;
        default:
          lbl2.setText("Some text");
          lbl2.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
          return lbl2;
      }
    }
  }

  static class DownloadListCellRenderer implements TableCellRenderer {
    private JPanel panel;

    public int getHeight() {
      return panel.getPreferredSize().height;
    }

    class RoundedBorder extends EmptyBorder {
      private Color corner;
      private Color line;

      public RoundedBorder(Color color, Color corner) {
        super(10, 10, 10, 10);
        this.line = color;
        this.corner = corner;
      }

      @Override
      public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        var g2 = (java.awt.Graphics2D) g.create();
        g2.setStroke(new BasicStroke(10));
        g2.setPaint(Color.BLACK);
        g2.fillRect(x, y, width, height);
        g2.setStroke(new BasicStroke(10));
        g2.setPaint(Color.ORANGE);
        g2.drawRoundRect(x, y, width, height, 5, 5);
      }
    }

    DownloadListCellRenderer() {
      panel = new JPanel(new BorderLayout(8, 5));
      var p4 = new JPanel(new FlowLayout());
      p4.setOpaque(false);
      var p3 = new JPanel(new BorderLayout());
      //p3.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
      p3.setBackground(Color.ORANGE);
      var icon = new JLabel(AppUtils.createSVGIcon("file-zip-fill.svg", 16, Color.WHITE));
      icon.setBorder(new EmptyBorder(5, 5, 5, 5));
      // icon.setOpaque(true);
      // icon.setBackground(Color.ORANGE);

      p3.add(icon);

      var chk = new JCheckBox();
      chk.setBorder(new EmptyBorder(0, 5, 0, 8));
      p4.add(chk);
      p4.add(p3);
      // p3.setBorder(new EmptyBorder(5,5,5,5));

      var content = new JPanel(new GridLayout(2, 1));
      content.setOpaque(false);
      var title = new JLabel("Some long title name for testing");
      title.setFont(title.getFont().deriveFont(12.0f));
      var statLabel =
          new JLabel("Downloaded 123MB of 378MB at 32.7MB/s ETA 01:33.03. Added on 13/02/2025");
      statLabel.setFont(statLabel.getFont().deriveFont(12.0f));
      statLabel.setForeground(Color.gray);

      content.add(title);
      content.add(statLabel);

      var p1 = new JPanel(new BorderLayout()); // new JPanel(new GridLayout(1, 2));
      var p5 = new JPanel();
      var prg = new JProgressBar();
      prg.setPreferredSize(new Dimension(60, 5));

      var p32 = Box.createVerticalBox();
      p32.setBorder(new EmptyBorder(0, 0, 0, 0));
      p32.add(new JLabel("Downloading.."));
      p32.add(Box.createRigidArea(new Dimension(5, 5)));
      p32.add(prg);

      p5.add(p32);
      p1.add(p5);

      var actions = Box.createHorizontalBox();
      actions.setBorder(new EmptyBorder(10, 10, 10, 10));
      actions.add(new JLabel(AppUtils.createSVGIcon("pause-circle-line.svg", 16, Color.GRAY)));
      actions.add(Box.createRigidArea(new Dimension(10, 10)));
      actions.add(new JLabel(AppUtils.createSVGIcon("delete-bin-line.svg", 16, Color.GRAY)));
      actions.add(Box.createRigidArea(new Dimension(5, 10)));
      // actions.add(new JLabel(AppUtils.createSVGIcon("more-2-fill.svg", 20, Color.GRAY)));

      p1.add(actions, BorderLayout.EAST);
      p1.setOpaque(false);
      p4.setOpaque(false);
      p5.setOpaque(false);

      panel.add(p4, BorderLayout.WEST);
      panel.add(content);
      panel.add(p1, BorderLayout.EAST);
      panel.setBorder(new EmptyBorder(10, 0, 0, 0));
    }

    @Override
    public Component getTableCellRendererComponent(
        JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      panel.setBackground(table.getBackground());
      return panel;
    }
  }

  static class LeftPanelCellRenderer implements ListCellRenderer<String> {

    @Override
    public Component getListCellRendererComponent(
        JList<? extends String> list,
        String value,
        int index,
        boolean isSelected,
        boolean cellHasFocus) {
      var label = new JLabel();
      label.setOpaque(true);
      label.setText(value);
      label.setIcon(AppUtils.createSVGIcon("arrow-up-down-fill.svg", 16, Color.GRAY));
      label.setIconTextGap(10);
      var color = isSelected ? list.getSelectionBackground() : list.getBackground();
      var lineBorder = new MatteBorder(0, 1, 0, 0, color);
      label.setBorder(new CompoundBorder(lineBorder, new EmptyBorder(10, 10, 10, 30)));
      label.setBackground(list.getBackground());
      label.setForeground(isSelected ? list.getSelectionForeground() : list.getForeground());
      return label;
    }
  }

  public static void main(String[] args) {
    System.setProperty("apple.awt.application.appearance", "system");
    FlatMacDarkLaf.setup();
    UIManager.put("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
    if ("TRUE".equalsIgnoreCase(System.getenv("CUSTOM_DECO"))) {
      // enable custom window decorations
      JFrame.setDefaultLookAndFeelDecorated(true);
      JDialog.setDefaultLookAndFeelDecorated(true);
    }
    System.out.println(Toolkit.getDefaultToolkit());
    // Run the application on the Event Dispatch Thread
    SwingUtilities.invokeLater(() -> new MainFrame3());
  }
}
