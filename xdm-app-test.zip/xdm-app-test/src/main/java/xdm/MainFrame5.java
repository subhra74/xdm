package xdm;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.Random;
import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.*;
import javax.swing.tree.TreeCellRenderer;

import com.formdev.flatlaf.util.SystemInfo;
import xdm.utils.AppUtils;

public class MainFrame5 extends JFrame {

  public MainFrame5(int rc) {
    // Set the title of the window
    super("Xtreme Download Manager");
    setIconImage(AppUtils.createSVGIcon("xdm-logo.svg", 32).getImage());

    // Set the default close operation
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Set the size of the window
    setSize(800, 500);

    // Center the window on the screen
    setLocationRelativeTo(null);

    // add(createToolbar(), BorderLayout.NORTH);
    var panel = new JPanel(new BorderLayout());
    panel.setBorder(new MatteBorder(1, 0, 0, 0, Color.black));
    panel.add(leftList(), BorderLayout.WEST);
    panel.add(rightPanel(rc));
    this.add(panel);

    System.out.println("Setting title..");
    getRootPane()
        .putClientProperty("JRootPane.titleBarBackground", UIManager.getColor("Table.background"));

    // Make the window visible
    setVisible(true);
  }

  private Component createLeftPanel() {
    var jpanel = new JPanel(new BorderLayout());
    var tree = new JTree();
    tree.setCellRenderer(new DownloadTreeCellRenderer());
    var jsp = new JScrollPane(tree);
    jsp.setPreferredSize(new Dimension(180, 100));
    jsp.setBorder(new EmptyBorder(0, 0, 0, 0));
    // jpanel.setBorder(new EmptyBorder(10, 10, 10, 0));
    jpanel.add(jsp);
    return jpanel;
  }

  private static int editingRow;

  static class DownloadTreeCellRenderer implements TreeCellRenderer {
    @Override
    public Component getTreeCellRendererComponent(
        JTree tree,
        Object value,
        boolean selected,
        boolean expanded,
        boolean leaf,
        int row,
        boolean hasFocus) {
      var lbl = new JLabel("Some long");
      lbl.setIcon(AppUtils.createSVGIcon("file-zip-fill.svg", 20, Color.GRAY));
      lbl.setIconTextGap(10);
      lbl.setOpaque(true);
      lbl.setBackground(
          selected ? UIManager.getColor("Tree.selectionBackground") : tree.getBackground());
      lbl.setForeground(
          selected ? UIManager.getColor("Tree.selectionForeground") : tree.getForeground());
      lbl.setBorder(new EmptyBorder(5, 5, 5, 5));
      return lbl;
    }
  }

  private static Component leftList() {
    var box = Box.createVerticalBox();
    var model = new DefaultListModel<String>();
    model.addElement("Finished");
    model.addElement("InProgress");
    var list = new JList<String>(model);
    list.setOpaque(false);
    list.setCellRenderer(new LeftPanelCellRenderer());
    list.setAlignmentX(0);
    box.add(list);

    var model2 = new DefaultListModel<String>();
    model2.addElement("All files");
    model2.addElement("Documents");
    model2.addElement("Music");
    model2.addElement("Video");
    model2.addElement("Applications");
    model2.addElement("Zip files");
    var list2 = new JList<String>(model2);
    list2.setBorder(new EmptyBorder(10, 0, 0, 0));
    list2.setOpaque(false);
    list2.setCellRenderer(new LeftPanelCellRenderer());
    list2.setAlignmentX(0);
    box.add(list2);
    box.setBorder(new EmptyBorder(10, 10, 10, 10));
    box.setOpaque(true);
    box.setBackground(UIManager.getColor("Table.background"));
    var jsp = new JScrollPane(box);
    jsp.setBorder(new MatteBorder(0, 0, 0, 1, Color.black));
    jsp.setOpaque(false);

    return jsp;
  }

  private static JButton createToolButton(String icon, String text) {
    var btnNew = new JButton(text);
    btnNew.setIconTextGap(10);
    btnNew.setIcon(AppUtils.createSVGIcon(icon, 16, Color.GRAY));
    btnNew.setForeground(Color.GRAY);
    btnNew.setMargin(new Insets(5, 5, 5, 5));
    return btnNew;
  }

  //  static Component createDownloadTable(JPanel container) {
  //    var renderer = new DownloadTableCellRenderer();
  //    var model = new DownloadTableModel();
  //    var table = new JTable(model);
  //    table.setRowHeight(32);
  //    table.setDefaultRenderer(Object.class, renderer);
  //    table.setFillsViewportHeight(true);
  //    table.putClientProperty("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
  //    var headerRenderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
  //    headerRenderer.setHorizontalAlignment(JLabel.LEFT);
  //    var jsp = new JScrollPane(table);
  //    jsp.setAutoscrolls(true);
  //    return jsp;
  //  }

  static Component createListTable(int rc) {
    var panel = new JPanel(new BorderLayout());
    panel.setBorder(new EmptyBorder(5, 5, 0, 0));
    panel.add(createToolbar(), BorderLayout.NORTH);
    var model = new DownloadListModel(rc);
    var renderer = new DownloadListCellRenderer(null);
    var editor = new DownloadListCellRenderer(model);

    var table = new JTable(model);
    table.addMouseMotionListener(
        new MouseAdapter() {
          @Override
          public void mouseMoved(MouseEvent e) {
            var row = table.rowAtPoint(e.getPoint());
            if (row != -1) {
              if (editingRow != row) {
                table.editCellAt(row, 0);
                editingRow = row;
              }
            } else {
              table.editingCanceled(new ChangeEvent(table));
            }
          }
        });
    table.setTableHeader(null);
    table.setRowHeight(renderer.getHeight());
    table.setDefaultRenderer(Object.class, renderer);
    table.setDefaultEditor(Object.class, editor);
    table.setFillsViewportHeight(true);
    table.setBackground(panel.getBackground());
    var jsp = new JScrollPane(table);
    jsp.setBorder(new EmptyBorder(0, 0, 0, 0));
    jsp.setAutoscrolls(true);

    panel.add(jsp);
    // jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    return panel;
  }

  private static Component createToolbar() {
    var toolbar = new JToolBar();
    toolbar.add(createToolButton("add-large-fill.svg", "New"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("pause-large-fill.svg", "Pause"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("delete-bin-line.svg", "Delete"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(createToolButton("sort-desc.svg", "Sort"));
    toolbar.add(Box.createRigidArea(new Dimension(10, 10)));

    toolbar.add(Box.createHorizontalGlue());

    var txtSearch = new JTextField(12);
    txtSearch.putClientProperty("JTextField.placeholderText", "Search");
    txtSearch.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    txtSearch.putClientProperty(
        "JTextField.trailingIcon", AppUtils.createSVGIcon("search-line.svg", 16, Color.GRAY));
    // txtSearch.setFont(txtSearch.getFont().deriveFont(14.0f));
    var d = txtSearch.getPreferredSize();
    var d2 = new Dimension(d.width, d.height + 5);
    txtSearch.setMaximumSize(d2);
    txtSearch.setPreferredSize(d2);
    toolbar.add(txtSearch);

    toolbar.add(Box.createRigidArea(new Dimension(5, 10)));
    toolbar.add(createToolButton("menu-line.svg", null));
    toolbar.setBorder(new EmptyBorder(5, 5, 0, 5));
    return toolbar;
  }

  private static Component rightPanel(int rc) {
    return createListTable(rc);
    //    var panel = new JPanel(new BorderLayout(0, 0));
    //
    //    panel.add(createListTable(panel));
    //    // panel.add(createDownloadTable(panel));
    //
    //    //panel.add(toolbar, BorderLayout.NORTH);
    //    panel.setBorder(
    //        new CompoundBorder(
    //            new MatteBorder(1, 0, 0, 0, UIManager.getColor("Component.borderColor")),
    //            new EmptyBorder(2, 5, 0, 0)));
    //    return panel;
  }

  static class DownloadTableModel extends AbstractTableModel {

    private String[] headers = new String[] {"Name", "Size", "Date", "%", "Status"};

    @Override
    public int getRowCount() {
      return 50;
    }

    @Override
    public int getColumnCount() {
      return 5;
    }

    @Override
    public String getColumnName(int column) {
      return headers[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
      return "hello";
    }
  }

  static class DownloadListModel extends AbstractTableModel {
    private java.util.List<Integer> values;
    private Timer timer;

    public DownloadListModel(int rc) {
      values = new ArrayList<>(rc);
      var r = new Random();
      for (var i = 0; i < rc; i++) {
        values.add(r.nextInt(0, 100));
      }
      timer =
          new Timer(
              1000,
              e -> {
                var row = r.nextInt(0, 3);
                var value = r.nextInt(0, 100);
                values.set(row, value);
                System.out.println("Updated: row=" + row + ", value=" + value);
                fireTableCellUpdated(row, 0);
              });
      timer.start();
    }

    @Override
    public int getRowCount() {
      return values.size();
    }

    @Override
    public int getColumnCount() {
      return 1;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
      return values.get(rowIndex);
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
      return true;
    }
  }

  //  static class DownloadTableCellRenderer implements TableCellRenderer {
  //
  //    @Override
  //    public Component getTableCellRendererComponent(
  //        JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
  //      switch (column) {
  //        case 0:
  //          var lbl = new JLabel("Some long title name for testing");
  //          lbl.setIcon(AppUtils.createSVGIcon("file-zip-fill.svg", 24, Color.GRAY));
  //          lbl.setIconTextGap(10);
  //          lbl.setOpaque(true);
  //          lbl.setBackground(isSelected ? table.getSelectionBackground() :
  // table.getBackground());
  //          lbl.setBorder(new EmptyBorder(5, 10, 5, 5));
  //          return lbl;
  //        default:
  //          var lbl2 = new JLabel("Some text");
  //          lbl2.setOpaque(true);
  //          lbl2.setBackground(isSelected ? table.getSelectionBackground() :
  // table.getBackground());
  //          lbl2.setBorder(new EmptyBorder(5, 5, 5, 5));
  //          return lbl2;
  //      }
  //    }
  //  }

  static Component createDownloadTable(JPanel container) {
    var renderer = new MainFrame3.DownloadTableCellRenderer();
    var model = new MainFrame3.DownloadTableModel();
    var table = new JTable();
    table.setModel(model);

    table.setRowHeight(32);
    table.setDefaultRenderer(Object.class, renderer);
    table.setFillsViewportHeight(true);
    table.putClientProperty("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
    var headerRenderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(JLabel.LEFT);
    var jsp = new JScrollPane(table);
    jsp.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
    jsp.setAutoscrolls(true);
    return jsp;
  }

  static class DownloadListCellRenderer implements TableCellRenderer, TableCellEditor {
    private JPanel panel;
    private JLabel lblSize, lblDate, lblSpeed, lblEta;
    private Component prgDetails;
    private Component lblDetails;
    private JProgressBar prg;

    public int getHeight() {
      return panel.getPreferredSize().height;
    }

    private JLabel createStatusLabel(String iconName, String text, Font font) {
      var l1 = new JLabel(AppUtils.createSVGIcon(iconName, 12, Color.GRAY));
      l1.setFont(font);
      l1.setForeground(Color.GRAY);
      l1.setText(text);
      return l1;
    }

    private int row = -1;
    private TableModel model;

    DownloadListCellRenderer(TableModel model) {
      System.out.println("DownloadListCellRenderer created");
      this.model = model;
      if (model != null) {
        model.addTableModelListener(
            new TableModelListener() {
              @Override
              public void tableChanged(TableModelEvent e) {
                var r = e.getFirstRow();
                System.out.println(r + "<=>" + row);
                if (r == row && row != -1) {
                  var value = model.getValueAt(row, 0);
                  prg.setValue((Integer) value);
                  //                  panel.revalidate();
                  //                  panel.repaint();
                }
              }
            });
      }
      panel = new JPanel(new BorderLayout(8, 5));
      var p4 = new JPanel(new FlowLayout());
      p4.setOpaque(false);
      var p3 = new JPanel(new BorderLayout());
      p3.setBackground(new Color(30, 144, 255));

      var icon = new JLabel(AppUtils.createSVGIcon("file-zip-fill.svg", 16, Color.WHITE));
      icon.setBorder(new EmptyBorder(7, 7, 7, 7));
      icon.addMouseListener(
          new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
              System.out.println("Entered: " + row);
            }

            @Override
            public void mouseExited(MouseEvent e) {
              System.out.println("Exited: " + row);
            }
          });
      var dim = icon.getPreferredSize();
      p3.putClientProperty(FlatClientProperties.STYLE, "arc: " + dim.width);

      // icon.setOpaque(true);
      // icon.setBackground(Color.ORANGE);

      p3.add(icon);

      //      var chk = new JCheckBox();
      //      chk.setBorder(new EmptyBorder(0, 0, 0, 8));
      //      p4.add(chk);
      p4.add(p3);
      // p3.setBorder(new EmptyBorder(5,5,5,5));

      var content = new JPanel(new GridLayout(2, 1, 0, 0));
      content.setOpaque(false);
      var title = new JLabel("Some long title name for testing");
      title.setVerticalAlignment(JLabel.BOTTOM);
      // title.setFont(title.getFont().deriveFont(12.0f));
      var pp = Box.createHorizontalBox();

      var fnt = title.getFont().deriveFont(12.0f);

      lblSize = createStatusLabel("arrow-down-line.svg", "234M / 456M", fnt);
      lblDate = createStatusLabel("calendar-line.svg", "June 24", fnt);
      lblSpeed = createStatusLabel("line-chart-line.svg", "6.5MB/s", fnt);
      lblEta = createStatusLabel("timer-line.svg", "00:02:34", fnt);

      pp.add(lblSize);
      pp.add(Box.createRigidArea(new Dimension(10, 5)));
      pp.add(lblDate);
      pp.add(Box.createRigidArea(new Dimension(10, 5)));
      pp.add(lblEta);
      pp.add(Box.createRigidArea(new Dimension(10, 5)));
      pp.add(lblSpeed);
      pp.add(Box.createRigidArea(new Dimension(10, 5)));

      var statLabel = new JLabel("Downloading 378 M at 2.6 MB/s ETA 00:02:56");
      statLabel.setVerticalAlignment(JLabel.TOP);
      // statLabel.setFont(statLabel.getFont().deriveFont(12.0f));
      statLabel.setForeground(Color.gray);

      content.add(title);
      content.add(pp);

      var p1 = new JPanel(new BorderLayout()); // new JPanel(new GridLayout(1, 2));
      var p5 = new JPanel();
      prg = new JProgressBar();
      prg.setPreferredSize(new Dimension(50, 5));
      prg.setAlignmentY(Component.CENTER_ALIGNMENT);
      // prg.setMaximumSize(new Dimension(120, 5));

      var prgDetails = Box.createVerticalBox();
      // p32.add(Box.createVerticalGlue());
      prgDetails.setBorder(new EmptyBorder(0, 0, 0, 0));
      var l32 = new JLabel("30%");
      l32.setHorizontalAlignment(JLabel.CENTER);
      l32.setHorizontalTextPosition(JLabel.CENTER);
      // l32.setFont(title.getFont().deriveFont(11.0f));
      prgDetails.add(l32);
      // p32.add(Box.createRigidArea(new Dimension(5, 5)));
      prgDetails.add(prg);

      this.prgDetails = prgDetails;
      // p32.add(Box.createVerticalGlue());
      // p32.add(Box.createRigidArea(new Dimension(5, 2)));
      // var l64 = new JLabel("Downloading..");
      // l64.setFont(title.getFont().deriveFont(11.0f));
      // p32.add(l64);
      this.lblDetails = new JLabel("Complete");
      p5.add(prgDetails);
      p5.add(lblDetails);
      p1.add(p5);

      var actions = Box.createHorizontalBox();
      actions.setBorder(new EmptyBorder(10, 10, 10, 10));
      var b1 = new JButton(AppUtils.createSVGIcon("pause-circle-line.svg", 16, Color.GRAY));
      b1.putClientProperty("JButton.buttonType", "toolBarButton");
      b1.addActionListener(
          e -> {
            System.out.println("Clicked: " + row);
          });
      var b2 = new JButton(AppUtils.createSVGIcon("delete-bin-line.svg", 16, Color.GRAY));
      b2.putClientProperty("JButton.buttonType", "toolBarButton");
      actions.add(
          b1); // new JLabel(AppUtils.createSVGIcon("pause-circle-line.svg", 16, Color.GRAY)));
      actions.add(Box.createRigidArea(new Dimension(10, 10)));
      actions.add(
          b2); // new JLabel(AppUtils.createSVGIcon("delete-bin-line.svg", 16, Color.GRAY)));
      actions.add(Box.createRigidArea(new Dimension(5, 10)));
      // actions.add(new JLabel(AppUtils.createSVGIcon("more-2-fill.svg", 20, Color.GRAY)));

      p1.add(actions, BorderLayout.EAST);
      p1.setOpaque(false);
      p4.setOpaque(false);
      p5.setOpaque(false);

      panel.add(p4, BorderLayout.WEST);
      panel.add(content);
      panel.add(p1, BorderLayout.EAST);
      panel.setBorder(new EmptyBorder(5, 5, 0, 0));
    }

    private Component getComp(JTable table, int row, Object value) {
      if (row % 3 == 0) {
        lblSpeed.setVisible(false);
        lblEta.setVisible(false);
        prgDetails.setVisible(false);
        lblDetails.setVisible(true);
      } else {
        lblSpeed.setVisible(true);
        lblEta.setVisible(true);
        prgDetails.setVisible(true);
        lblDetails.setVisible(false);
      }
      if (table != null) {
        panel.setBackground(table.getBackground());
      }
      prg.setValue(value != null ? (int) value : 0);
      return panel;
    }

    @Override
    public Component getTableCellRendererComponent(
        JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      return getComp(table, row, value);
    }

    @Override
    public Component getTableCellEditorComponent(
        JTable table, Object value, boolean isSelected, int row, int column) {
      this.row = row;
      return getComp(table, row, value);
    }

    @Override
    public Object getCellEditorValue() {
      return 99;
    }

    @Override
    public boolean isCellEditable(EventObject anEvent) {
      return true;
    }

    @Override
    public boolean shouldSelectCell(EventObject anEvent) {
      return false;
    }

    @Override
    public boolean stopCellEditing() {
      row = -1;
      return true;
    }

    @Override
    public void cancelCellEditing() {
      row = -1;
    }

    @Override
    public void addCellEditorListener(CellEditorListener l) {
      System.out.println("addCellEditorListener Called");
    }

    @Override
    public void removeCellEditorListener(CellEditorListener l) {}
  }

  static class LeftPanelCellRenderer implements ListCellRenderer<String> {

    @Override
    public Component getListCellRendererComponent(
        JList<? extends String> list,
        String value,
        int index,
        boolean isSelected,
        boolean cellHasFocus) {
      var label = new JLabel();
      label.setText(value);
      label.setIcon(AppUtils.createSVGIcon("arrow-up-down-fill.svg", 20, Color.GRAY));
      label.setIconTextGap(10);
      // var color = isSelected ? list.getSelectionBackground() : list.getBackground();
      // var lineBorder = new MatteBorder(0, 1, 0, 0, color);
      // label.setBorder(new CompoundBorder(lineBorder, new EmptyBorder(10, 10, 10, 30)));
      label.setBorder(new EmptyBorder(5, 10, 5, 30));
      label.setOpaque(isSelected);
      label.setBackground(list.getBackground());
      label.setForeground(isSelected ? list.getSelectionForeground() : list.getForeground());
      return label;
    }
  }

  public static void main(String[] args) {
    System.setProperty("apple.awt.application.appearance", "system");
    FlatMacDarkLaf.setup();
    UIManager.put("TableHeader.cellMargins", new Insets(0, 10, 0, 0));
    var rc = Integer.parseInt(args.length == 1 ? args[0] : "0");
    // Run the application on the Event Dispatch Thread
    SwingUtilities.invokeLater(() -> new MainFrame5(rc));
  }
}
