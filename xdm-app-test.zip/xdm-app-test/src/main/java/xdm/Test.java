package xdm;

// import org.apache.hc.client5.http.classic.methods.HttpGet;
// import org.apache.hc.client5.http.impl.classic.HttpClients;
// import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;

//import okhttp3.ConnectionPool;
//import okhttp3.OkHttpClient;
//import okhttp3.Request;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.TimeUnit;

public class Test {
  public void test() {
    new Thread(
            () -> {
              try {
                var request =
                    HttpRequest.newBuilder()
                        .uri(new URI("https://httpbin.org/bytes/" + (100 * 1024 * 1024)))
                        .build();

                var client = HttpClient.newHttpClient();
                var response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
                var b = new byte[1024 * 1024 * 5];
                var inputStream = response.body();
                while (true) {
                  var x = inputStream.read(b);
                  if (x == -1) break;
                }
                inputStream.close();

                //                var client =
                //                    new OkHttpClient.Builder()
                //                        .connectionPool(new ConnectionPool(10, 5,
                // TimeUnit.SECONDS))
                //                        .build();
                //                var request =
                //                    new Request.Builder()
                //                        .url("https://httpbin.org/bytes/" + (100 * 1024 * 1024))
                //                        .build();
                //                var response = client.newCall(request).execute();
                //                var b = new byte[1024 * 1024 * 5];
                //                var inputStream = response.body().byteStream();
                //                while (true) {
                //                  var x = inputStream.read(b);
                //                  if (x == -1) break;
                //                }
                System.out.println("Done");

                //                var hc =
                //                    HttpClients.custom()
                //                        .setConnectionManager(
                //                            PoolingHttpClientConnectionManagerBuilder.create()
                //                                .setMaxConnPerRoute(100)
                //                                .setMaxConnTotal(200)
                //                                .build())
                //                        .build();
                //                var httpGet = new HttpGet("https://httpbin.org/bytes/" + (100 *
                // 1024 * 1024));
                //                var res = hc.executeOpen(null, httpGet, null);
                //                var b = new byte[1024 * 1024 * 5];
                //                var inputStream = res.getEntity().getContent();
                //                while (true) {
                //                  var x = inputStream.read(b);
                //                  if (x == -1) break;
                //                }
                //                System.out.println("Done");Done
              } catch (Exception e) {
                e.printStackTrace();
              }
            })
        .start();
  }
}
